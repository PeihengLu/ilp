package uk.ac.ed.inf;

import com.mapbox.geojson.Point;
import java.util.*;


public class Drone {
    /** the current location of the drone */
    private LongLat currLoc;
    private String currLocName;
    /** angle to reach the next location */
    private int angle;
    /** where to go next*/
    private LongLat nextLoc;
    /** whether the drone is close to target location */
    private boolean arrived;
    /** how many moves the drone got left */
    private int moves;

    private Map map;

    /** the name of the locations that the drone needs to follow for current order */
    private final Queue<Stack<Integer>> path = new LinkedList<>();
    /** store the points the drone has taken and write it to the output geojson file */
    private List<Point> pathRec = new ArrayList<>();

    DatabaseUtils databaseUtils;


    /**
     *
     * @param currLoc
     * @param locName
     * @param databaseUtils used to record drones' path to flightPath table
     */
    public Drone(LongLat currLoc, String locName, DatabaseUtils databaseUtils) {
        this.currLoc = currLoc;
        this.currLocName = locName;
        this.arrived = false;
        this.moves = 1500;
        this.databaseUtils = databaseUtils;
    }


    public AbstractMap.SimpleEntry<Stack<Integer>, LongLat> planAStar(LongLat cur, LongLat target) {
        Node start = new Node(cur, 0, cur.distanceTo(target), 0, null);
        // contains the node we have encountered but haven't analysed yet
        Queue<Node> open = new PriorityQueue<>();
        // contains node whose children are all added to the list or disqualified
        List<Node> closed = new ArrayList<>();
        // the best path to target given by the algorithm
        Node solution = null;

        open.add(start);

        while (!open.isEmpty()) {
            Node best = open.peek();
            if (best.loc.closeTo(target)) {
                solution = best;
                break;
            }

            for (int i = 0; i <= 350; i += 10) {
                LongLat next = best.loc.nextPosition(i);
                if (Map.checkNFZ(best.loc, next) || !next.isConfined()) continue;
                Node child = new Node(next, best.g + 1, next.distanceTo(target), i, best);
                if (!open.contains(child) && !closed.contains(child)) {
                    open.add(child);
                } else {
                    if (open.contains(child)) {
                        Node childSame = open.get(open.indexOf(child));
                        if (childSame.f > child.f) {
                            open.remove(childSame);
                            open.add(child);
                        }
                    }
                    if (closed.contains(child)) {
                        Node childSame = closed.get(closed.indexOf(child));
                        if (childSame.f > child.f) {
                            closed.remove(childSame);
                            open.add(child);
                        }
                    }
                }
            }

            open.remove(best);
            closed.add(best);
        }

        if (solution == null) {
            System.err.println("A star didn't find a solution");
            return null;
        }

        Stack<Integer> aStar = new Stack<>();
        LongLat reached = solution.loc;

        while (solution.parent != null) {
            aStar.push(solution.angleFromParent);
            solution = solution.parent;
        }

        return new AbstractMap.SimpleEntry<>(aStar, reached);
    }

    public boolean moveAStar(String orderNo, Stack<Integer> pathPlanned) {

        // follow the path planned by A star
        while (!pathPlanned.isEmpty()) {
            if (moves == 0) return false;
            int anglePlaned = pathPlanned.pop();
            setAngle(anglePlaned);
            planNextMove();
            databaseUtils.storePath(orderNo, currLoc, anglePlaned, nextLoc);
            makeNextMove();
            addToPathRec(currLoc);
        }

        return true;
    }


    /**
     * call this instead of getAngle when the drone has reached a destination
     */
    public void hover() {
        this.angle = -999;
        planNextMove();
        makeNextMove();
    }


    private void setAngle(int angle) {
        this.angle = angle;
    }


    public void planNextMove() {
        nextLoc = currLoc.nextPosition(angle);
    }

    /**
     * change currPos to nextPos
     */
    public void makeNextMove() {
        if (moves == 0) System.err.println("out of power");
        currLoc = nextLoc;
        moves --;
    }


    public void addToPath(Stack<Integer> partOfPath) {
        path.add(partOfPath);
    }

    public void addToPathRec(LongLat longLat) {
        Point point = Point.fromLngLat(longLat.longitude, longLat.latitude);
        pathRec.add(point);
    }

    public boolean isPathEmpty () {
        return path.isEmpty();
    }

    public Stack<Integer> getNextPathForOrder() {
        return path.poll();
    }

    public List<Point> getPathRecord() {
        return pathRec;
    }

    /** return how many moves the drone got left */
    public int getMoves() {
        return moves;
    }

    public LongLat getCurrLoc() {
        return currLoc;
    }

    public String getCurrLocName() {
        return currLocName;
    }
}
