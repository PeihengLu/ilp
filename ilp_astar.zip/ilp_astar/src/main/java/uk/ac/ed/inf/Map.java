package uk.ac.ed.inf;

import com.mapbox.geojson.Point;
import com.mapbox.geojson.Polygon;

import java.util.*;

/**
 * The representation of the map with all necessary information for the program
 */
public class Map {
    /** the locations of points of interest */
    public final HashMap<String, LongLat> locations = new HashMap<>();
    /** names of all locations of interests, used for composing and indexing the
     * graph to search on */
    public static final List<String> locationNames = new ArrayList<>();
    /** no-fly zones */
    public static final List<Polygon> noFlyZones = new ArrayList<Polygon>();


    /**
     * check if a line represented by p1 and p2 intercept with any edges of no-fly zones, also p2 cannot escape
     * our confinement area
     * @param p1 starting point
     * @param p2 target location
     * @return false if it doesn't go into the no-fly zones or confinement area, true otherwise
     */
    public static boolean checkNFZ(LongLat p1, LongLat p2) {
        if (!p2.isConfined()) return true;
        Point point1 = Point.fromLngLat(p1.longitude, p1.latitude);
        Point point2 = Point.fromLngLat(p2.longitude, p2.latitude);

        for (Polygon polygon: noFlyZones) {
            if (GeoJsonUtils.pathInterceptPolygon(point1, point2, polygon)) return true;
        }

        return false;
    }

}
