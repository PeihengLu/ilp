package uk.ac.ed.inf;

import com.mapbox.geojson.*;
import com.mapbox.geojson.Polygon;

import java.util.*;

/**
 * The lunch delivery drone control system
 */
public class App 
{
    /** GeoJsonUtils, DatabaseUtils and W3WUtils services */
    private static GeoJsonUtils geoJsonUtils;
    private static DatabaseUtils databaseUtils;
    private static W3WUtils wUtils;

    /** create a menus object for calculating delivery cost and information about the shops */
    private static Menus menus;
    /** drone object to store drone's location and energy information, also the planned path for it to follow*/
    private static Drone drone;
    /** map object storing useful locations for orders on the specified date */
    private static Map map = new Map();
    private static final Queue<Order> orders = new PriorityQueue<>(Collections.reverseOrder());

    private static String outputFile;
    private static String outputFileFailed;

    public static void main( String[] args )
    {
        long startTime = System.nanoTime();

        int totalOrders ;
        int orderSent = 0;
        int totalEarned = 0;
        int totalCost = 0;
        // first add the starting and ending point Appleton Tower into our
        // points of interests
        map.locations.put("Appleton Tower", LongLat.AT);
        map.locationNames.add("Appleton Tower");


        if (args.length != 5) {
            System.err.println("You should enter 5 arguments: day, month, year, webserver port and database port!");
        }
        // fetch the commandline arguments and store them in variables
        String day = args[0];
        String month = args[1];
        String year = args[2];
        String port = args[3];
        String dbPort = args[4];
        // date of the orders to retrieve
        String date = String.join("-", year, month, day);
        // name of the server for connection
        String name = "localhost";
        // name of the output geojson file storing the path
        outputFile = "../" + String.join("-", "drone", day, month, year) + ".geojson";
        outputFileFailed = "../" + String.join("-", "drone", day, month, year) + "failed" + ".geojson";

        // connect menus to the server
        menus = new Menus(name, port);
        // start the GeoJsonUtils, DatabaseUtils and W3WUtils services
        geoJsonUtils = new GeoJsonUtils(name, port);
        databaseUtils = new DatabaseUtils(name, dbPort, "derbyDB");
        wUtils = new W3WUtils(name, port);
        // initialize the Drone at appleton tower
        drone = new Drone(LongLat.AT, "Appleton Tower", databaseUtils);
        // add the starting point to the stored path
        drone.addToPathRec(LongLat.AT);


        // get the no-fly zones
        if (!getNoFlyZones()) {
            System.err.println("Cannot get the information about no fly zones");;
            return;
        }
        // get all the landmarks and add them to locations known by the drone
        if (!getLandmarks()) {
            System.err.println("Cannot get the information about landmarks");;
            return;
        }
        // get the shop information and add them to locations known by the drone
        if (!getShopsInfo()) {
            System.err.println("Cannot get the information about shops");;
            return;
        }
        // retrieve all orders for a specific date
        if (!getOrders(date)) {
            System.err.printf("Error retrieving orders for %s", date);
            return;
        }


        totalOrders = orders.size();
        // go through all the orders and plan the path for each
        while (!orders.isEmpty()) {
            Order currOrder = orders.poll();
            totalCost += currOrder.deliveryCost;
            // check if an order is available and plan its path if it is
            if (checkAvailability(currOrder)) {
                //System.out.printf("Apologies, cannot finish order %s, not enough power left, lost %d pence\n", currOrder.orderNo, currOrder.deliveryCost);
                continue;
            }

            // if the program gets here, then the order will be carried out,
            // so store it to our orders database
            databaseUtils.storeOrder(currOrder.orderNo, currOrder.deliverTo.words, currOrder.deliveryCost);

            while (!drone.isPathEmpty()) {
                Stack<Integer> pathNow = drone.getNextPathForOrder();
                drone.moveAStar(currOrder.orderNo, pathNow);
                drone.hover();
            }

            orderSent ++;
            totalEarned += currOrder.deliveryCost;
        }


        AbstractMap.SimpleEntry<Stack<Integer>, LongLat> toAppleton = drone.planAStar(drone.getCurrLoc(), LongLat.AT);
        if (!drone.moveAStar("NoOrder", toAppleton.getKey())) {
            System.err.println("Out of power");
        }

        LineString result = LineString.fromLngLats(drone.getPathRecord());
        GeoJsonUtils.writeGeoJson(FeatureCollection.fromFeature(Feature.fromGeometry(result)), outputFile);

        long endTime = System.nanoTime();
        double time = (endTime - startTime) / 1000000000.0;

        System.out.printf("Out of %d orders, %d orders were sent, made %d pence, %.3f money made, and returned to AT? %b\n", totalOrders, orderSent, totalEarned, (double) totalEarned / (double) totalCost, drone.getCurrLoc().closeTo(LongLat.AT));
        System.out.printf("takes %.2f seconds\n", time);
    }

    private static boolean getNoFlyZones() {
        List<Feature> nfz = GeoJsonUtils.readGeoJson(geoJsonUtils.noFlyZone);
        if (nfz == null) {
            System.err.println("Problem reading noflyzone geojson file");
            return false;
        }
        for (Feature f: nfz) {
            if (f.geometry() instanceof Polygon) {
                map.noFlyZones.add((Polygon) f.geometry());
            }
        }
        return true;
    }

    private static boolean getLandmarks() {
        // get the landmarks
        List<Feature> landmarks = GeoJsonUtils.readGeoJson(geoJsonUtils.landmarks);
        if (landmarks == null) {
            System.err.println("Problem reading GeoJson file landmarks");
            return false;
        }
        for (Feature landmark: landmarks) {
            Location loc = wUtils.convertW3W(landmark.getStringProperty("location"));
            if (loc == null) {
                System.err.println("Problem reading W3W address file");
                return false;
            }
            map.locations.put(landmark.getStringProperty("name"), new LongLat(loc.coordinates));
            map.locationNames.add(landmark.getStringProperty("name"));
        }
        return true;
    }

    /**
     * get the information of all the shops providing food for the service
     * @return
     */
    private static boolean getShopsInfo() {
        // get all the shops
        Collection<Shop> allShops = menus.provider.values();
        for (Shop shop: allShops) {
            Location loc = wUtils.convertW3W(shop.getLocation());
            if (loc == null) {
                System.err.println("Problem reading W3W address file");
                return false;
            }
            if (!map.locations.containsKey(shop.getName())) {
                map.locations.put(shop.getName(), new LongLat(loc.coordinates));
                map.locationNames.add(shop.getName());
            }
        }
        return true;
    }


    /**
     * Check if the drone has enough power to finish the order or if finishing current order
     * will leave enough battery for the drone to return to Appleton Tower, add the shops, delivery address
     * for the order to path if the drone has enough power
     * @param currOrder the order number of the order whose availability needs to be checked
     * @return
     */
    private static boolean checkAvailability(Order currOrder) {
        // name of the delivery address
        String end = currOrder.deliverTo.words;
        LongLat startLoc = drone.getCurrLoc();
        LongLat endLoc = map.locations.get(end);

        // distance to Appleton, only used for estimation here so doesn't need to start at the precise location of where the drone would be
        AbstractMap.SimpleEntry<Stack<Integer>, LongLat> toAppleton = drone.planAStar(endLoc, LongLat.AT);

        if (currOrder.shops.size() == 2) {
            String shopAName = currOrder.shops.get(0).getName();
            String shopBName = currOrder.shops.get(1).getName();

            LongLat shopALoc = map.locations.get(shopAName);
            LongLat shopBLoc = map.locations.get(shopBName);

            AbstractMap.SimpleEntry<Stack<Integer>, LongLat> startToA = drone.planAStar(startLoc, shopALoc);
            AbstractMap.SimpleEntry<Stack<Integer>, LongLat> aToB = drone.planAStar(startToA.getValue(), shopBLoc);
            AbstractMap.SimpleEntry<Stack<Integer>, LongLat>  bToEnd = drone.planAStar(aToB.getValue(), endLoc);

            // from start to A to B to end
            AbstractMap.SimpleEntry<Stack<Integer>, LongLat> startToB = drone.planAStar(startLoc, shopBLoc);
            // bToA is the same size with aToB, but calculate again to make sure the path is precise
            AbstractMap.SimpleEntry<Stack<Integer>, LongLat> bToA = drone.planAStar(startToB.getValue(), shopALoc);
            AbstractMap.SimpleEntry<Stack<Integer>, LongLat>  aToEnd = drone.planAStar(bToA.getValue(), endLoc);

            int planAFirst = startToA.getKey().size() + aToB.getKey().size() + bToEnd.getKey().size();
            int planBFirst = startToB.getKey().size() + bToA.getKey().size() + aToEnd.getKey().size();

            if (planAFirst > planBFirst) {
                if (planAFirst + toAppleton.getKey().size() + 3 > drone.getMoves()) {
                    return true;
                }
                drone.addToPath(startToA.getKey());
                drone.addToPath(aToB.getKey());
                drone.addToPath(bToEnd.getKey());
            } else {
                // same size with aToB but in reverse order, important as we are using stack
                if (planBFirst + toAppleton.getKey().size() + 3 > drone.getMoves()) {
                    return true;
                }
                drone.addToPath(startToB.getKey());
                drone.addToPath(bToA.getKey());
                drone.addToPath(aToEnd.getKey());
            }
        } else {
            String shopName = currOrder.shops.get(0).getName();
            LongLat shopLoc = map.locations.get(shopName);
            AbstractMap.SimpleEntry<Stack<Integer>, LongLat> toShop = drone.planAStar(startLoc, shopLoc);
            AbstractMap.SimpleEntry<Stack<Integer>, LongLat> toEnd = drone.planAStar(toShop.getValue(), endLoc);
            if (toShop.getKey().size() + toEnd.getKey().size() + toAppleton.getKey().size() + 2 > drone.getMoves()) {
                return true;
            }
            drone.addToPath(toShop.getKey());
            drone.addToPath(toEnd.getKey());
        }
        return false;
    }


    /**
     *
     * @param date
     * @return true no error occurs, false otherwise
     */
    private static boolean getOrders(String date) {
        // get the order details
        List<String[]> orderNoDeliver = databaseUtils.getOrders(date);
        if (orderNoDeliver == null) {
            System.err.println("Problem reading orders table");
            return false;
        }
        for (String[] order : orderNoDeliver) {
            String orderNo = order[0];
            // add all deliver destinations to the locations map as well
            // I simply named all the destinations of orders with their
            // corresponding w3w address
            String w3w = order[1];
            Location deliverTo = wUtils.convertW3W(w3w);
            if (deliverTo == null) {
                System.err.println("Problem reading W3W address file");
                return false;
            }
            if (!map.locations.containsKey(w3w)) {
                map.locations.put(w3w, new LongLat(deliverTo.coordinates));
                map.locationNames.add(w3w);
            }

            List<String> items = databaseUtils.getItems(orderNo);
            if (items == null) {
                System.err.println("Problem reading the orderDetails table");
                return false;
            }

            int deliveryCost = menus.getDeliveryCost(items.toArray(new String[0]));
            if (deliveryCost == -1) {
                System.err.println("Problem reading the menus file or illegal order");
                return false;
            }

            List<Shop> shops = new ArrayList<>(menus.getShopped());
            // create an Order object containing the information just acquired
            // and add it to the list of orders on the specified date
            Order newOrder = new Order(orderNo, w3w, items, deliverTo, shops, deliveryCost);
            orders.add(newOrder);
        }
        return true;
    }
}
